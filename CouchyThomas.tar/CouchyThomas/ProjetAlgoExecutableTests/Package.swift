// swift-tools-version:4.2
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "ProjetAlgoExecutableTests",
    dependencies: [
        // Dependencies declare other packages that this package depends on.
        // .package(url: /* package url */, from: "1.0.0"),
	.package(url: "../ProjetAlgoLibrairies", from: "1.0.0"),
    ],
    targets: [
        // Targets are the basic building blocks of a package. A target can define a module or a test suite.
        // Targets can depend on other targets in this package, and on products in packages which this package depends on.
        .target(name: "carteTest",dependencies: []),
	.target(name: "caseTest",dependencies: []),
	.target(name: "champBatailleTest",dependencies: ["carte","case"]),
	.target(name: "joueurTest",dependencies: ["champBataille","main","pioche","royaume"]),
	.target(name: "mainTest",dependencies: ["carte"]),
	.target(name: "partieTest",dependencies: ["joueur"]),
	.target(name: "piocheTest",dependencies: ["carte"]),
	.target(name: "royaumeTest",dependencies: ["carte"]),
    ]
)
