import XCTest

import ProjetAlgoExecutableTestsTests

var tests = [XCTestCaseEntry]()
tests += ProjetAlgoExecutableTestsTests.allTests()
XCTMain(tests)