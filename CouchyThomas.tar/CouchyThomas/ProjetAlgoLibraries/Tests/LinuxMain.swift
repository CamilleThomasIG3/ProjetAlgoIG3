import XCTest

import ProjetAlgoLibrariesTests

var tests = [XCTestCaseEntry]()
tests += ProjetAlgoLibrariesTests.allTests()
XCTMain(tests)