import XCTest

import ProjetAlgoExecutableMainTests

var tests = [XCTestCaseEntry]()
tests += ProjetAlgoExecutableMainTests.allTests()
XCTMain(tests)