import XCTest

import ProtocolUnqueraBourratTests

var tests = [XCTestCaseEntry]()
tests += ProtocolUnqueraBourratTests.allTests()
XCTMain(tests)