import XCTest

import MainUnqueraBourratTests

var tests = [XCTestCaseEntry]()
tests += MainUnqueraBourratTests.allTests()
XCTMain(tests)