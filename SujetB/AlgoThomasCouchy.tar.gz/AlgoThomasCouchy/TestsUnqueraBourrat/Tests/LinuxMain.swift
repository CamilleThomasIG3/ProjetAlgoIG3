import XCTest

import TestsUnqueraBourratTests

var tests = [XCTestCaseEntry]()
tests += TestsUnqueraBourratTests.allTests()
XCTMain(tests)