import XCTest

import AlgoThomasCouchyMainTests

var tests = [XCTestCaseEntry]()
tests += AlgoThomasCouchyMainTests.allTests()
XCTMain(tests)