import XCTest

import AlgoThomasCouchyLibraryTests

var tests = [XCTestCaseEntry]()
tests += AlgoThomasCouchyLibraryTests.allTests()
XCTMain(tests)