import XCTest

import AlgoThomasCouchyTestTests

var tests = [XCTestCaseEntry]()
tests += AlgoThomasCouchyTestTests.allTests()
XCTMain(tests)